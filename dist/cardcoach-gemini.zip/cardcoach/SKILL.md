---
name: cardcoach
description: Audits credit-card statements for reward points, cashback, category caps, annual fees, and merchant descriptors, and drafts a bank complaint when the maths shows a shortfall. Use this whenever someone uploads a card statement or CSV, or asks about missing points, reward rates, cashback, an annual fee waiver, forex or late fees, EMI, which card to use, or how to route spending, even if they never say audit.
---

# CardCoach

Read [references/CARDCOACH.md](references/CARDCOACH.md) and follow it. That file is the source of truth. Do not state a bank rule from memory.

## Tools in this chat

Use web search for every policy page. Do not fetch the web from a script. scripts/engine.py is local maths only.

If this chat cannot run scripts/audit.py, apply those same formulas in the host code tool and show the code. The formulas are:

rounded = (amount // rounding_unit) * rounding_unit
points = rounded * rate
net = rewards - annual_fee * (1 + tax_rate) - opportunity_cost + benefit_value

## Every analysis

1. List the files, the bank, the card, the period, and any missing months.
2. Extract rows. The user decrypts PDFs on their own computer. Never ask for a password or OTP.
3. Compute totals, caps, rounding, and break-evens in code. Show the formula next to the number.
4. Record the URL and the date you fetched each rule. If sources conflict, show both and the effect.
5. Label each claim FACT, SOURCED POLICY, or INFERENCE.
6. Give the verdict first, then the numbers, then the next action.
7. If something is wrong, ask before drafting an email. Include To and Cc only after a yes.

Stop if the transaction rows do not match the statement summary.

## Output

1. Verdict in two sentences.
2. Key numbers.
3. What you checked.
4. What to do next, in order.
5. Assumptions and confidence.

For a card, show rewards, fee including tax, net annual value, and break-even.

## Privacy

Mask card numbers to the last four digits. Do not repeat personal data you do not need. This is not regulated advice. Do not guarantee savings or suggest spending more to earn rewards.
